"""Sliding-window failure counter (in-memory, single process)."""
import threading
from collections import defaultdict, deque


class FailureLimiter:
    def __init__(self, max_failures: int, window: float, clock):
        self.max_failures = max_failures
        self.window = window
        self.clock = clock
        self._events = defaultdict(deque)
        self._lock = threading.Lock()
        self._last_sweep = clock()

    def _sweep_if_due(self, now):
        """Drop keys whose newest failure has expired. Without this, every distinct
        username/IP ever seen stays in memory forever (unbounded growth).
        Runs at most every window/2, so cost is amortised and state is bounded to
        roughly 1.5 windows of traffic. Expired keys can never be blocking, so
        removing them cannot weaken a lockout."""
        if now - self._last_sweep < self.window / 2:
            return
        self._last_sweep = now
        for key in [k for k, q in self._events.items() if not q or now - q[-1] >= self.window]:
            del self._events[key]

    def _prune(self, key, now):
        q = self._events[key]
        while q and now - q[0] >= self.window:
            q.popleft()
        if not q:
            self._events.pop(key, None)
        return q

    def retry_after(self, key) -> int:
        """Seconds until another attempt is allowed (0 = allowed now)."""
        with self._lock:
            now = self.clock()
            self._sweep_if_due(now)
            q = self._prune(key, now)
            if len(q) >= self.max_failures:
                return max(1, int(q[0] + self.window - now) + 1)
            return 0

    def record(self, key):
        with self._lock:
            self._sweep_if_due(self.clock())
            self._events[key].append(self.clock())

    def reset(self, key):
        with self._lock:
            self._events.pop(key, None)

    def size(self) -> int:
        """Number of keys currently held (for tests and monitoring)."""
        with self._lock:
            return len(self._events)
