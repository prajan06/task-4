"""Password hashing with scrypt (memory-hard KDF, standard library only).

Stored format: scrypt$N$r$p$<salt b64>$<hash b64>
Parameters travel with the hash so they can be raised later (see needs_rehash).
"""
import base64
import hashlib
import hmac
import os
import unicodedata

# OWASP-equivalent scrypt cost (N=2^15, r=8, p=3: 32 MiB, ~0.2 s on a modern CPU).
# Other equal-strength options: N=2^17/p=1, N=2^16/p=2.
N, R, P = 2**15, 8, 3
SALT_LEN = 16
DK_LEN = 32
# Upper bounds on parameters read back from the database. A tampered row must not be
# able to force more work than the app itself would ever choose.
MAX_N, MAX_R, MAX_P = 2**17, 16, 16


def _prep(password: str) -> bytes:
    return unicodedata.normalize("NFKC", password).encode("utf-8")


def _scrypt(password: str, salt: bytes, n: int, r: int, p: int) -> bytes:
    return hashlib.scrypt(
        _prep(password), salt=salt, n=n, r=r, p=p, dklen=DK_LEN,
        maxmem=256 * n * r + 1024 * 1024,
    )


def hash_password(password: str, *, n: int = N, r: int = R, p: int = P) -> str:
    salt = os.urandom(SALT_LEN)  # unique random salt per password
    dk = _scrypt(password, salt, n, r, p)
    b64 = lambda b: base64.b64encode(b).decode("ascii")
    return f"scrypt${n}${r}${p}${b64(salt)}${b64(dk)}"


def _parse(stored: str):
    scheme, n, r, p, salt, dk = stored.split("$")
    if scheme != "scrypt":
        raise ValueError("unknown scheme")
    n, r, p = int(n), int(r), int(p)
    if not (2 <= n <= MAX_N) or n & (n - 1) or not (1 <= r <= MAX_R) or not (1 <= p <= MAX_P):
        raise ValueError("bad parameters")
    return n, r, p, base64.b64decode(salt), base64.b64decode(dk)


def verify_password(password: str, stored: str) -> bool:
    """Constant-time comparison; malformed hashes simply fail."""
    try:
        n, r, p, salt, expected = _parse(stored)
        actual = _scrypt(password, salt, n, r, p)
    except (ValueError, TypeError):
        return False
    return hmac.compare_digest(actual, expected)


def needs_rehash(stored: str) -> bool:
    try:
        n, r, p, _, _ = _parse(stored)
    except (ValueError, TypeError):
        return True
    return (n, r, p) != (N, R, P)


# Verified against when a username does not exist, so unknown-user and
# wrong-password requests cost about the same time.
DUMMY_HASH = hash_password("dummy-password-used-only-for-timing")
