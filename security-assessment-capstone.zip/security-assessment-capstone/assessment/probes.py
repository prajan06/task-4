"""Reproducible assessment probes for secure-auth-lab (white-box, in-process, no network).

Usage:  python assessment/probes.py [--out evidence/baseline_results]
Writes <out>.txt and <out>.json. Exit code 1 if any check FAILs.
All data is synthetic. Each check uses a fresh app and a throwaway database.
"""
import importlib.metadata as md
import json
import logging
import os
import re
import sqlite3
import statistics
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from auth_lab import create_app  # noqa: E402
from auth_lab.app import COOKIE_NAME  # noqa: E402

SYNTH_PW = "synthetic-Passphrase-for-testing-1"  # fictional; not a real credential
WRONG_PW = "definitely-the-wrong-passphrase-9"
RESULTS = []


class FakeClock:
    def __init__(self, t=1_000_000.0):
        self.t = t

    def __call__(self):
        return self.t

    def advance(self, s):
        self.t += s


class Target:
    """A fresh app + throwaway DB for one check."""

    def __init__(self, **cfg):
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = os.path.join(self.tmp.name, "auth.db")  # does not exist yet
        self.clock = cfg.pop("CLOCK", FakeClock())
        self.app = create_app({"DB_PATH": self.db_path, "CLOCK": self.clock, **cfg})
        self.client = self.app.test_client(use_cookies=False)

    def call(self, method, path, body=None, token=None, ip="203.0.113.10", raw=None, ctype="application/json"):
        kw = dict(base_url="https://localhost", environ_overrides={"REMOTE_ADDR": ip},
                  headers={"Cookie": f"{COOKIE_NAME}={token}"} if token else {})
        if raw is not None:
            kw.update(data=raw, content_type=ctype)
        elif body is not None:
            kw["json"] = body
        return getattr(self.client, method)(path, **kw)

    def register(self, u="alice", p=SYNTH_PW, **kw):
        return self.call("post", "/register", {"username": u, "password": p}, **kw)

    def login(self, u="alice", p=SYNTH_PW, **kw):
        return self.call("post", "/login", {"username": u, "password": p}, **kw)

    @staticmethod
    def token(resp):
        for h in resp.headers.getlist("Set-Cookie"):
            m = re.match(rf"{re.escape(COOKIE_NAME)}=([^;]*)", h)
            if m:
                return m.group(1)

    def close(self):
        self.tmp.cleanup()


def record(cid, area, title, status, evidence):
    RESULTS.append(dict(id=cid, area=area, check=title, status=status, evidence=evidence))


def check(cid, area, title):
    def deco(fn):
        try:
            status, evidence = fn()
        except Exception as exc:  # a crashing probe is itself a finding
            status, evidence = "FAIL", f"probe raised {type(exc).__name__}: {exc}"
        record(cid, area, title, status, evidence)
        return fn
    return deco


# ------------------------------------------------------------ configuration
@check("C01", "Configuration", "Debug mode and testing mode are off by default")
def _():
    t = Target()
    ok = not t.app.debug and not t.app.config.get("DEBUG") and not t.app.config.get("TESTING")
    t.close()
    return ("PASS" if ok else "FAIL"), f"app.debug={t.app.debug}, TESTING={t.app.config.get('TESTING')}"


@check("C02", "Configuration", "Session cookie flags and security headers")
def _():
    t = Target()
    t.register()
    r = t.login()
    cookie = r.headers.get("Set-Cookie", "")
    want_cookie = [cookie.startswith(COOKIE_NAME + "="), "HttpOnly" in cookie, "Secure" in cookie,
                   "SameSite=Lax" in cookie, "Path=/" in cookie, "Domain" not in cookie]
    h = t.call("get", "/me").headers
    want_hdr = [h.get("Cache-Control") == "no-store", h.get("X-Content-Type-Options") == "nosniff",
                h.get("X-Frame-Options") == "DENY", "default-src 'none'" in h.get("Content-Security-Policy", ""),
                "max-age" in h.get("Strict-Transport-Security", "")]
    t.close()
    ok = all(want_cookie) and all(want_hdr)
    return ("PASS" if ok else "FAIL"), f"cookie checks {want_cookie}; header checks {want_hdr}"


@check("C03", "Configuration", "Database file (holds password hashes) is not group/world accessible")
def _():
    old = os.umask(0o022)  # typical default umask
    try:
        t = Target()
        mode = os.stat(t.db_path).st_mode & 0o777
        t.close()
    finally:
        os.umask(old)
    ok = mode & 0o077 == 0
    return ("PASS" if ok else "FAIL"), f"file mode created by create_app under umask 022: {oct(mode)}"


# ----------------------------------------------------------- authentication
@check("C04", "Authentication", "Passwords are never stored in plaintext")
def _():
    t = Target()
    t.register()
    stored = sqlite3.connect(t.db_path).execute("SELECT password_hash FROM users").fetchone()[0]
    t.close()
    ok = SYNTH_PW not in stored and stored.startswith("scrypt$")
    return ("PASS" if ok else "FAIL"), f"stored prefix: {stored.split('$')[0]}$..., contains plaintext: {SYNTH_PW in stored}"


@check("C05", "Authentication", "KDF cost meets OWASP minimum-equivalent scrypt parameters")
def _():
    t = Target()
    t.register()
    stored = sqlite3.connect(t.db_path).execute("SELECT password_hash FROM users").fetchone()[0]
    t.close()
    _, n, r, p, *_ = stored.split("$")
    n, r, p = int(n), int(r), int(p)
    owasp = [(2**17, 1), (2**16, 2), (2**15, 3), (2**14, 5), (2**13, 10)]
    ok = r >= 8 and any(n >= n0 and p >= p0 for n0, p0 in owasp)
    return ("PASS" if ok else "FAIL"), (f"stored cost: N=2^{n.bit_length() - 1}, r={r}, p={p}; "
                                        f"OWASP-equivalent minimums: N=2^17/p=1, 2^16/p=2, 2^15/p=3, 2^14/p=5")


@check("C06", "Authentication", "Generic login errors; throttling does not reveal which accounts exist")
def _():
    t = Target()
    t.register()
    # one failure each, so a real and a non-existent account start from the same state
    a, b = t.login(p=WRONG_PW, ip="198.51.100.1"), t.login(u="nobody", ip="198.51.100.2")
    same = a.status_code == b.status_code == 401 and a.get_json() == b.get_json()
    codes_known = [t.login(p=WRONG_PW, ip="198.51.100.3").status_code for _ in range(5)]
    codes_ghost = [t.login(u="nobody", p=WRONG_PW, ip="198.51.100.4").status_code for _ in range(5)]
    t.close()
    ok = same and codes_known == codes_ghost
    return ("PASS" if ok else "FAIL"), f"identical 401 body: {same}; real-account codes {codes_known}; non-existent-account codes {codes_ghost}"


@check("C07", "Authentication", "Response time similar for unknown user vs wrong password (enumeration via timing)")
def _():
    t = Target(LOGIN_MAX_FAILURES_PER_ACCOUNT=10**6, LOGIN_MAX_FAILURES_PER_IP=10**6)
    t.register()
    known, unknown = [], []
    for i in range(8):
        s = time.perf_counter(); t.login(p=WRONG_PW); known.append(time.perf_counter() - s)
        s = time.perf_counter(); t.login(u=f"ghost{i}", p=WRONG_PW); unknown.append(time.perf_counter() - s)
    t.close()
    mk, mu = statistics.median(known), statistics.median(unknown)
    ratio = mu / mk
    ok = 0.7 <= ratio <= 1.4
    return ("PASS" if ok else "FAIL"), f"median known-user {mk * 1000:.0f} ms, unknown-user {mu * 1000:.0f} ms, ratio {ratio:.2f} (n=8 each)"


@check("C08", "Authentication", "Session lifecycle: rotation, logout, idle expiry, no fixation, token hashed at rest")
def _():
    t = Target()
    t.register()
    t1 = t.token(t.login())
    t2 = t.token(t.login())
    rotated = t.call("get", "/me", token=t1).status_code == 401 and t.call("get", "/me", token=t2).status_code == 200
    t.call("post", "/logout", {}, token=t2)
    logout_ok = t.call("get", "/me", token=t2).status_code == 401
    t3 = t.token(t.login())
    t.clock.advance(16 * 60)
    idle_ok = t.call("get", "/me", token=t3).status_code == 401
    fixed = t.token(t.login(ip="203.0.113.50"))
    fixation_ok = fixed != "attacker-chosen"
    t4 = t.token(t.login())
    stored = [r[0] for r in sqlite3.connect(t.db_path).execute("SELECT token_hash FROM sessions")]
    hashed = t4 not in stored
    t.close()
    ok = all([rotated, logout_ok, idle_ok, fixation_ok, hashed])
    return ("PASS" if ok else "FAIL"), f"rotation={rotated} logout_invalidates={logout_ok} idle_expiry={idle_ok} no_fixation={fixation_ok} token_hashed={hashed}"


# --------------------------------------------------------------- validation
@check("C09", "Validation", "Malformed, hostile and type-confused inputs are rejected cleanly (no 5xx, JSON errors)")
def _():
    t = Target()
    t.register()
    cases = {
        "nosql-style objects": ("/login", {"username": {"$ne": ""}, "password": {"$ne": ""}}, None),
        "sql metacharacters": ("/login", {"username": "alice' OR '1'='1", "password": "x"}, None),
        "NUL in username": ("/login", {"username": "alice\u0000", "password": "x"}, None),
        "password as list": ("/login", {"username": "alice", "password": ["x"]}, None),
        "oversized username": ("/login", {"username": "A" * 5000, "password": "x"}, None),
        "fullwidth username": ("/register", {"username": "\uff41\uff4c\uff49\uff43\uff45", "password": SYNTH_PW}, None),
        "NUL-padded password": ("/register", {"username": "bob_01", "password": "a\u0000" * 10}, None),
        "JSON null": ("/register", None, "null"),
        "JSON number": ("/login", None, "123"),
        "truncated JSON": ("/login", None, '{"a":'),
        "form-encoded body": ("/login", None, "username=a&password=b"),
    }
    bad = []
    for name, (path, body, raw) in cases.items():
        ctype = "application/x-www-form-urlencoded" if name == "form-encoded body" else "application/json"
        r = t.call("post", path, body, raw=raw, ctype=ctype) if raw is not None else t.call("post", path, body)
        ok = 400 <= r.status_code < 500 and r.mimetype == "application/json"
        if not ok:
            bad.append(f"{name} -> {r.status_code} {r.mimetype}")
    t.close()
    return ("PASS" if not bad else "FAIL"), (f"{len(cases)} payloads sent; problems: {bad or 'none'}")


@check("C10", "Validation", "Deeply nested JSON (inside the 4 KB body cap) is handled without an unhandled error")
def _():
    t = Target()  # not in TESTING mode, so unhandled exceptions surface as HTTP 500 like in production
    raw = "[" * 2000 + "]" * 2000  # 4000 bytes
    r = t.call("post", "/login", raw=raw)
    body = r.get_data(as_text=True)[:70].replace("\n", " ")
    after = t.call("get", "/me").status_code
    t.close()
    ok = r.status_code == 400 and r.mimetype == "application/json"
    return ("PASS" if ok else "FAIL"), f"status={r.status_code}, content-type={r.mimetype}, body starts: {body!r}; service still answers afterwards: {after == 401}"


# ------------------------------------------------------------------ logging
@check("C11", "Logging", "Security events are written to an audit trail without secrets")
def _():
    records = []

    class Collect(logging.Handler):
        def emit(self, rec):
            records.append(rec.getMessage())

    lg = logging.getLogger("auth_lab.audit")
    old_level, h = lg.level, Collect()
    lg.setLevel(logging.INFO)
    lg.addHandler(h)
    try:
        t = Target()
        t.register()
        for _ in range(6):
            t.login(p=WRONG_PW, ip="198.51.100.9")
        t.register(u="carol")
        tok = t.token(t.login(u="carol"))
        t.call("post", "/logout", {}, token=tok)
        t.close()
    finally:
        lg.removeHandler(h)
        lg.setLevel(old_level)
    seen = set()
    for m in records:
        try:
            d = json.loads(m)
            seen.add((d.get("event"), d.get("result")))
        except ValueError:
            pass
    need = {("register", "success"), ("password_login", "failure"), ("password_login", "throttled"),
            ("password_login", "success"), ("logout", "success")}
    blob = "\n".join(records)
    leaked = SYNTH_PW in blob or WRONG_PW in blob or (tok and tok in blob)
    ok = need <= seen and not leaked
    return ("PASS" if ok else "FAIL"), (f"{len(records)} audit records captured; missing event/result pairs: "
                                        f"{sorted(need - seen) or 'none'}; secrets leaked: {bool(leaked)}")


# ---------------------------------------------------------------- resources
@check("C12", "Resource use", "Expired rate-limiter state is reclaimed (memory stays bounded)")
def _():
    t = Target()
    sizes = lambda: sum(getattr(l, "size", lambda l=l: len(l._events))()
                        for l in (t.app.extensions["login_account_limiter"], t.app.extensions["login_ip_limiter"]))
    for i in range(300):  # 300 unique usernames, rotating source IPs (10 each) so no IP is throttled
        t.login(u=f"user{i:04d}", p=WRONG_PW, ip=f"192.0.2.{i // 10 + 1}")
    before = sizes()
    t.clock.advance(2000)  # well past the 900 s window: everything above is expired
    t.login(u="late", p=WRONG_PW, ip="192.0.2.250")
    after = sizes()
    t.close()
    ok = after <= 20
    return ("PASS" if ok else "FAIL"), f"limiter keys held: {before} after 300 unique failures; {after} after the window expired and one more request"


# -------------------------------------------------------------- dependencies
@check("C13", "Dependencies", "requirements.txt pins exact versions")
def _():
    lines = [l.strip() for l in (ROOT / "requirements.txt").read_text().splitlines()]
    reqs = [re.split(r"\s+#", l)[0].strip() for l in lines if l and not l.startswith("#")]
    unpinned = [r for r in reqs if "==" not in r]
    installed = {d: md.version(d) for d in ("Flask", "Werkzeug", "Jinja2", "MarkupSafe", "itsdangerous", "click", "blinker")
                 if d in {x.metadata["Name"] for x in md.distributions()}}
    return ("PASS" if not unpinned else "FAIL"), f"unpinned: {unpinned or 'none'}; installed: {installed}"


@check("C14", "Dependencies", "Known-vulnerability scan (pip-audit)")
def _():
    try:
        import pip_audit  # noqa: F401
    except ImportError:
        return "SKIPPED", "pip-audit not installed and the assessment sandbox has no network; run `pip-audit -r requirements.txt` (also wired into CI)"
    return "SKIPPED", "pip-audit present but needs network access to the advisory database"


# -------------------------------------------------- accepted-risk demonstrations
@check("C15", "Authentication", "Targeted lockout: an outsider can lock a known account (documented trade-off)")
def _():
    t = Target()
    t.register()
    for _ in range(5):
        t.login(p=WRONG_PW, ip="198.51.100.77")
    r = t.login(ip="203.0.113.99")  # the real user, correct password, different IP
    t.close()
    return "ACCEPTED", f"after 5 wrong guesses from one IP, the real user's correct login from another IP got HTTP {r.status_code}"


@check("C16", "Authentication", "Registration reveals whether a username exists (documented trade-off)")
def _():
    t = Target()
    t.register()
    r = t.register()
    t.close()
    return "ACCEPTED", f"duplicate registration returned HTTP {r.status_code}: {r.get_json()}"


@check("C17", "Authentication", "Verification refuses scrypt parameters larger than the app would ever generate")
def _():
    import base64
    from auth_lab import hashing
    b64 = lambda b: base64.b64encode(b).decode()
    stored = f"scrypt$%d$8$1${b64(b'0' * 16)}${b64(b'0' * 32)}" % (2**19)  # 512 MiB, ~1.7 s of work per attempt if honoured
    start = time.perf_counter()
    result = hashing.verify_password("synthetic", stored)
    elapsed = time.perf_counter() - start
    ok = result is False and elapsed < 0.5
    return ("PASS" if ok else "FAIL"), f"verify() of a hash with N=2^19 (512 MiB) returned {result} after {elapsed:.2f} s (limit 0.5 s)"


def main():
    out = None
    if "--out" in sys.argv:
        out = Path(sys.argv[sys.argv.index("--out") + 1])
    width = max(len(r["check"]) for r in RESULTS)
    lines = [f"secure-auth-lab assessment probes | git {os.popen('git -C ' + str(ROOT) + ' rev-parse --short HEAD').read().strip()}", ""]
    for r in RESULTS:
        lines.append(f"[{r['status']:<7}] {r['id']} {r['area']:<14} {r['check']}")
        lines.append(f"{'':11}evidence: {r['evidence']}")
    counts = {s: sum(1 for r in RESULTS if r["status"] == s) for s in ("PASS", "FAIL", "ACCEPTED", "SKIPPED")}
    lines += ["", "Summary: " + ", ".join(f"{k}={v}" for k, v in counts.items())]
    text = "\n".join(lines)
    print(text)
    if out:
        out.parent.mkdir(parents=True, exist_ok=True)
        out.with_suffix(".txt").write_text(text + "\n")
        out.with_suffix(".json").write_text(json.dumps(RESULTS, indent=2) + "\n")
    sys.exit(1 if counts["FAIL"] else 0)


if __name__ == "__main__":
    main()
