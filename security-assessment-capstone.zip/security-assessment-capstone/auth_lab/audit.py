"""Structured security audit log: one JSON object per line.

Field names follow the Security Log Investigation task (ts, event, result, user_id,
source_ip) so the same detection rules (brute force, spraying, unusual access) apply.

Never logged: passwords, password hashes, session tokens or cookies.
json.dumps escapes control characters, so attacker-supplied text such as a username
containing a newline cannot forge extra log lines.
"""
import json
import logging
import os
from datetime import datetime, timezone

logger = logging.getLogger("auth_lab.audit")
logger.addHandler(logging.NullHandler())  # library convention: silent unless the host app configures a sink
MAX_FIELD = 64  # truncate attacker-controlled values


def log(event, result, now, *, level=logging.INFO, **fields):
    record = {"ts": datetime.fromtimestamp(now, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
              "event": event, "result": result}
    for key, value in fields.items():
        if value is not None:
            record[key] = str(value)[:MAX_FIELD]
    logger.log(level, json.dumps(record, ensure_ascii=True, separators=(",", ":")))


def configure_file(path):
    """Append audit records to `path` (owner-only, 0600). Safe to call repeatedly."""
    path = os.path.abspath(path)
    for h in logger.handlers:
        if isinstance(h, logging.FileHandler) and h.baseFilename == path:
            return
    os.close(os.open(path, os.O_CREAT | os.O_WRONLY | os.O_APPEND, 0o600))
    os.chmod(path, 0o600)
    handler = logging.FileHandler(path, encoding="utf-8")
    handler.setFormatter(logging.Formatter("%(message)s"))
    logger.addHandler(handler)
    if logger.level == logging.NOTSET or logger.level > logging.INFO:
        logger.setLevel(logging.INFO)
