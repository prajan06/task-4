"""Server-side input validation. Never trust client-side checks."""
import re
import unicodedata

USERNAME_RE = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")
PASSWORD_MIN = 12
PASSWORD_MAX = 128  # cap length so huge inputs can't be used for DoS

COMMON_PASSWORDS = {
    "password1234", "123456789012", "qwertyuiop12", "letmein123456",
    "welcome12345", "administrator", "iloveyou1234", "password12345",
    "changeme1234", "1234567890123", "passwordpassword", "qwertyqwerty",
}


def validate_username(username) -> list[str]:
    if not isinstance(username, str) or not USERNAME_RE.fullmatch(username):
        return ["Username must be 3-32 characters: letters, digits, '_', '.', '-'."]
    return []


def validate_password(password, username="") -> list[str]:
    if not isinstance(password, str):
        return ["Password must be a string."]
    pw = unicodedata.normalize("NFKC", password)
    errors = []
    if len(pw) < PASSWORD_MIN:
        errors.append(f"Password must be at least {PASSWORD_MIN} characters.")
    if len(pw) > PASSWORD_MAX:
        errors.append(f"Password must be at most {PASSWORD_MAX} characters.")
    if "\x00" in pw:
        errors.append("Password contains invalid characters.")
    lowered = pw.lower()
    if lowered in COMMON_PASSWORDS or len(set(lowered)) < 4:
        errors.append("Password is too common or too repetitive.")
    if isinstance(username, str) and len(username) >= 3 and username.lower() in lowered:
        errors.append("Password must not contain the username.")
    return errors
