"""Regression tests added during the Defensive Security Assessment Capstone.
One class per finding (F1..F5); each fails on the baseline code and passes after its fix."""
import base64
import json
import pathlib
import re
import logging
import os
import sqlite3
import stat
import tempfile
import time
import unittest

from auth_lab import create_app, hashing
from auth_lab.ratelimit import FailureLimiter
from auth_lab.app import COOKIE_NAME
from tests.test_auth import Base, GOOD_PW


class TestF1DatabaseFilePermissions(unittest.TestCase):
    def mode(self, path):
        return stat.S_IMODE(os.stat(path).st_mode)

    def test_new_database_is_owner_only_even_with_permissive_umask(self):
        old = os.umask(0o000)
        try:
            with tempfile.TemporaryDirectory() as d:
                path = os.path.join(d, "auth.db")
                create_app({"DB_PATH": path})
                self.assertEqual(self.mode(path), 0o600)
        finally:
            os.umask(old)

    def test_existing_world_readable_database_is_tightened(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "auth.db")
            open(path, "w").close()
            os.chmod(path, 0o644)
            create_app({"DB_PATH": path})
            self.assertEqual(self.mode(path), 0o600)

    def test_database_still_works_after_hardening(self):
        with tempfile.TemporaryDirectory() as d:
            app = create_app({"DB_PATH": os.path.join(d, "auth.db")})
            r = app.test_client().post("/register", base_url="https://localhost",
                                       json={"username": "alice", "password": "correct-horse-battery-staple"})
            self.assertEqual(r.status_code, 201)


class TestF2KdfCost(unittest.TestCase):
    PW = "correct-horse-battery-staple"

    def test_new_hashes_use_owasp_equivalent_parameters(self):
        _, n, r, p, *_ = hashing.hash_password(self.PW).split("$")
        n, r, p = int(n), int(r), int(p)
        owasp = [(2**17, 1), (2**16, 2), (2**15, 3), (2**14, 5), (2**13, 10)]
        self.assertTrue(r >= 8 and any(n >= n0 and p >= p0 for n0, p0 in owasp))

    def test_oversized_parameters_rejected_quickly(self):
        b64 = lambda b: base64.b64encode(b).decode()
        for n, r, p in [(2**19, 8, 1), (2**20, 8, 1), (2**15, 1000, 1), (2**15, 8, 1000)]:
            stored = f"scrypt${n}${r}${p}${b64(b'0' * 16)}${b64(b'0' * 32)}"
            start = time.perf_counter()
            self.assertFalse(hashing.verify_password("x", stored))
            self.assertLess(time.perf_counter() - start, 0.5, (n, r, p))

    def test_legacy_weak_hash_still_verifies_and_is_upgraded_at_login(self):
        with tempfile.TemporaryDirectory() as d:
            path = os.path.join(d, "auth.db")
            app = create_app({"DB_PATH": path})
            legacy = hashing.hash_password(self.PW, n=2**14, r=8, p=1)  # the v1 parameters
            with sqlite3.connect(path) as c:
                c.execute("INSERT INTO users (username, password_hash, created_at) VALUES (?,?,?)",
                          ("alice", legacy, 0))
            self.assertTrue(hashing.needs_rehash(legacy))
            r = app.test_client().post("/login", base_url="https://localhost",
                                       json={"username": "alice", "password": self.PW})
            self.assertEqual(r.status_code, 200)
            new = sqlite3.connect(path).execute("SELECT password_hash FROM users").fetchone()[0]
            self.assertNotEqual(new, legacy)
            self.assertFalse(hashing.needs_rehash(new))
            self.assertTrue(hashing.verify_password(self.PW, new))


class TestF3AuditLogging(Base):
    def records(self, cm):
        return [json.loads(line.split(":", 2)[2]) for line in cm.output]

    def test_security_events_are_logged_with_expected_fields(self):
        with self.assertLogs("auth_lab.audit", level="INFO") as cm:
            self.register()
            for _ in range(6):
                self.login(password="wrong-password-123", ip="198.51.100.9")
            tok = self.token_from(self.login())  # alice is already locked: throttled
            self.register(username="carol")
            tok = self.token_from(self.login(username="carol"))
            self.call("post", "/logout", {}, token=tok)
        recs = self.records(cm)
        pairs = {(r["event"], r["result"]) for r in recs}
        for expected in [("register", "success"), ("password_login", "failure"), ("password_login", "throttled"),
                         ("password_login", "success"), ("account_throttle", "started"), ("logout", "success")]:
            self.assertIn(expected, pairs)
        failure = next(r for r in recs if r["event"] == "password_login" and r["result"] == "failure")
        self.assertEqual(failure["source_ip"], "198.51.100.9")
        self.assertEqual(failure["user_id"], "alice")
        self.assertEqual(failure["reason"], "bad_password")
        self.assertRegex(failure["ts"], r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")

    def test_unknown_user_reason_is_internal_only(self):
        with self.assertLogs("auth_lab.audit", level="INFO") as cm:
            resp = self.login(username="nobody")
        self.assertEqual(self.records(cm)[0]["reason"], "unknown_user")
        self.assertNotIn("unknown", resp.get_data(as_text=True).lower())  # client sees only the generic message

    def test_no_secrets_in_logs(self):
        secret_pw = "my-very-secret-passphrase-42"
        with self.assertLogs("auth_lab.audit", level="INFO") as cm:
            self.register(password=secret_pw)
            self.login(password="another-secret-attempt-77")
            tok = self.token_from(self.login(password=secret_pw))
            self.call("post", "/logout", {}, token=tok)
        blob = "\n".join(cm.output)
        for secret in (secret_pw, "another-secret-attempt-77", tok):
            self.assertNotIn(secret, blob)
        self.assertNotIn("scrypt$", blob)

    def test_log_injection_is_neutralised(self):
        evil = 'alice\n{"event":"password_login","result":"success","user_id":"admin"}'
        with self.assertLogs("auth_lab.audit", level="INFO") as cm:
            self.login(username=evil)
        self.assertEqual(len(cm.output), 1)  # one record, not two
        self.assertNotIn("\n", cm.output[0])
        rec = self.records(cm)[0]
        self.assertEqual(rec["result"], "failure")
        self.assertLessEqual(len(rec["user_id"]), 64)

    def test_file_sink_is_owner_only_and_json_lines(self):
        path = os.path.join(tempfile.mkdtemp(), "audit.log")
        app = create_app({"DB_PATH": self.db_path + ".2", "CLOCK": self.clock, "AUDIT_LOG_PATH": path})
        try:
            app.test_client().post("/login", base_url="https://localhost",
                                   json={"username": "nobody", "password": "x" * 12})
            self.assertEqual(stat.S_IMODE(os.stat(path).st_mode), 0o600)
            with open(path) as fh:
                lines = [json.loads(l) for l in fh]
            self.assertEqual(lines[0]["event"], "password_login")
        finally:
            lg = logging.getLogger("auth_lab.audit")
            for h in list(lg.handlers):
                if isinstance(h, logging.FileHandler):
                    lg.removeHandler(h)
                    h.close()
            if os.path.exists(self.db_path + ".2"):
                os.unlink(self.db_path + ".2")


class TestF4LimiterMemory(unittest.TestCase):
    def setUp(self):
        self.t = [1000.0]
        self.lim = FailureLimiter(max_failures=5, window=900, clock=lambda: self.t[0])

    def test_expired_keys_are_reclaimed(self):
        for i in range(500):
            self.lim.record(f"user{i}")
        self.assertEqual(self.lim.size(), 500)
        self.t[0] += 1000  # past the window
        self.lim.retry_after("someone-else")  # any traffic triggers the sweep
        self.assertEqual(self.lim.size(), 0)

    def test_sweep_never_removes_an_active_lockout(self):
        for _ in range(5):
            self.lim.record("victim")
        self.t[0] += 460  # past window/2 so a sweep runs, but before the window ends
        self.lim.record("noise")
        self.assertIn("victim", self.lim._events)
        self.assertGreater(self.lim.retry_after("victim"), 0)  # still locked
        self.t[0] += 500  # window now over
        self.assertEqual(self.lim.retry_after("victim"), 0)

    def test_limiter_behaviour_unchanged_for_normal_use(self):
        for _ in range(4):
            self.lim.record("alice")
        self.assertEqual(self.lim.retry_after("alice"), 0)
        self.lim.record("alice")
        self.assertGreater(self.lim.retry_after("alice"), 0)
        self.lim.reset("alice")
        self.assertEqual(self.lim.retry_after("alice"), 0)


class TestF5DependencyPinning(unittest.TestCase):
    def test_every_requirement_is_pinned_to_an_exact_version(self):
        root = pathlib.Path(__file__).resolve().parent.parent
        lines = [l.split("#")[0].strip() for l in (root / "requirements.txt").read_text().splitlines()]
        reqs = [l for l in lines if l]
        self.assertTrue(reqs)
        for r in reqs:
            self.assertRegex(r, r"^[A-Za-z0-9_.-]+==\d+(\.\d+)*$", r)

    def test_installed_flask_matches_the_pin(self):
        import importlib.metadata as md
        root = pathlib.Path(__file__).resolve().parent.parent
        pinned = re.search(r"^Flask==(\S+)", (root / "requirements.txt").read_text(), re.M).group(1)
        self.assertEqual(md.version("Flask"), pinned)


if __name__ == "__main__":
    unittest.main()
