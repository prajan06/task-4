"""Local development server. Use HTTPS (or a browser on localhost) because the
session cookie is marked Secure. Never run Flask's dev server in production."""
import logging

from auth_lab import create_app

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    # JSON audit records are appended to audit.log (created owner-only, 0600).
    create_app({"AUDIT_LOG_PATH": "audit.log"}).run(host="127.0.0.1", port=5000)
