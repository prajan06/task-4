"""Server-side sessions. Only a SHA-256 of the token is stored, so a leaked
database does not leak usable session cookies."""
import hashlib
import secrets


def _h(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def create(conn, user_id: int, now: float) -> str:
    token = secrets.token_urlsafe(32)  # 256 bits from the OS CSPRNG
    conn.execute(
        "INSERT INTO sessions (token_hash, user_id, created_at, last_seen) VALUES (?,?,?,?)",
        (_h(token), user_id, now, now),
    )
    conn.commit()
    return token


def lookup(conn, token, now: float, idle: float, absolute: float):
    """Return the user row for a valid session, else None. Slides the idle timer."""
    if not token or not isinstance(token, str):
        return None
    row = conn.execute(
        "SELECT s.created_at, s.last_seen, u.id AS uid, u.username "
        "FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.token_hash = ?",
        (_h(token),),
    ).fetchone()
    if row is None:
        return None
    if now - row["created_at"] >= absolute or now - row["last_seen"] >= idle:
        destroy(conn, token)
        return None
    conn.execute("UPDATE sessions SET last_seen = ? WHERE token_hash = ?", (now, _h(token)))
    conn.commit()
    return row


def destroy(conn, token) -> None:
    if token and isinstance(token, str):
        conn.execute("DELETE FROM sessions WHERE token_hash = ?", (_h(token),))
        conn.commit()


def destroy_all_for_user(conn, user_id: int) -> None:
    conn.execute("DELETE FROM sessions WHERE user_id = ?", (user_id,))
    conn.commit()


def purge_expired(conn, now: float, idle: float, absolute: float) -> None:
    conn.execute(
        "DELETE FROM sessions WHERE ? - created_at >= ? OR ? - last_seen >= ?",
        (now, absolute, now, idle),
    )
    conn.commit()
